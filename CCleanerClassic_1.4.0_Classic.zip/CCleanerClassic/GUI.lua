------------------
-- Get/Set Funcs
------------------
local function GetChannels()
	local icList = ""
	local iNext = 0
	if CCLEANER_CLASSIC_CHANNELS ~= nil then
		for i = 1, #CCLEANER_CLASSIC_CHANNELS do
			if CCLEANER_CLASSIC_CHANNELS[i] ~= nil then
				icList = icList .. CCLEANER_CLASSIC_CHANNELS[i]
			end
			iNext = i + 1
			if iNext <= #CCLEANER_CLASSIC_CHANNELS and CCLEANER_CLASSIC_CHANNELS[iNext] ~= nil then
				icList = icList .. ";"
			end
		end
	end
	return icList
end

local function SetChannels(icList)
	CCLEANER_CLASSIC_CHANNELS = {}
	for chname in string.gmatch(icList, "[^;]+") do
		if chname ~= nil and string.len(chname) then table.insert(CCLEANER_CLASSIC_CHANNELS, chname) end
	end		
end

local function GetKeywords(frame, tbl)
	frame:SetText("")
	if type(tbl) == "table" and #tbl > 0 then
		table.sort(tbl)
		local text
		for i=1, #tbl do
			if not text then
				text = tbl[i]
			else
				text = text.."\n"..tbl[i]
			end
		end
		frame:SetText(text)
	end
end

local function AddRemoveKeywords(input, editbox, tbl)
	-- format new text...
	local t = input:GetText()
	if t == "" or t:find("^ *$") then input:SetText("") return end
	t = t:lower()

	-- find if exists...
	local found
	for i=1, #tbl do
		if tbl[i] == t then found = i end
	end

	-- if found...
	if found then
		table.remove(tbl, found)
	else
		table.insert(tbl, t)
	end

	-- resort...
	table.sort(tbl)
	local text
	for i=1, #tbl do
		if not text then
			text = tbl[i]
		else
			text = text.."\n"..tbl[i]
		end
	end

	input:SetText("")
	editbox:SetText(text or "")
end

local function TableCopy(src, dest)
	for k 		in pairs(dest) 	do dest[k] = nil end 	-- clear
	for k, v 	in pairs(src) 	do dest[k] = v   end 	-- copy
end

------------------
-- Main Frame
------------------
local ccc = CreateFrame("Frame", nil, UIParent, "BasicFrameTemplate")
ccc:SetSize(650, 300)
ccc:SetPoint("CENTER")
ccc:SetClampedToScreen(true)
ccc:EnableMouse(true)
ccc:SetMovable(true)
ccc:RegisterForDrag("LeftButton")
ccc:SetScript("OnDragStart", 	function(self) self:StartMoving() end)
ccc:SetScript("OnDragStop", 	function(self) self:StopMovingOrSizing() end)
ccc:Hide()

------------------
-- Title
------------------
ccc.title = ccc:CreateFontString(nil, nil, "GameFontNormalLarge")
ccc.title:SetPoint("TOPLEFT", 15, -5)
ccc.title:SetText("ChatCleanerClassic " .. string.format("v%s", GetAddOnMetadata("CCleanerClassic", "Version")))

------------------
-- Slash Command
------------------
SlashCmdList["ChatCleanerClassic"] = function() ccc:Show() end
SLASH_ChatCleanerClassic1 = "/chatcleanerclassic"
SLASH_ChatCleanerClassic2 = "/ccc"

------------------
-- General Options
------------------
local cccTxtGeneral = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtGeneral:SetPoint("TOPLEFT", ccc.title, "BOTTOMLEFT", 0, -20)
cccTxtGeneral:SetText("General Options:")

------------------
-- Enabled
------------------
local cccChkEnabled = CreateFrame("CheckButton", nil, ccc, "OptionsBaseCheckButtonTemplate")
cccChkEnabled:SetPoint("TOPLEFT", cccTxtGeneral, "TOPRIGHT", 20, 5)
cccChkEnabled:SetScript("OnClick", function(frame)
	CCLEANER_CLASSIC_ENABLED = frame:GetChecked()
end)
cccChkEnabled:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:AddLine("Enable/disable filtering.", 0.5, 0.5, 0)
	GameTooltip:Show()
end)
local cccTxtEnabled = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtEnabled:SetPoint("LEFT", cccChkEnabled, "RIGHT", 0, 1)
cccTxtEnabled:SetText("Enabled")

------------------
-- Filter Friendly
------------------
local cccChkFilterFriendly = CreateFrame("CheckButton", nil, ccc, "OptionsBaseCheckButtonTemplate")
cccChkFilterFriendly:SetPoint("TOPLEFT", cccTxtEnabled, "TOPRIGHT", 13, 5)
cccChkFilterFriendly:SetScript("OnClick", function(frame)
	CCLEANER_CLASSIC_FILTER_FRIENDLY = frame:GetChecked()
end)
cccChkFilterFriendly:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:AddLine("Filter out chat from friends, guildies, raiders, etc.", 0.5, 0.5, 0)
	GameTooltip:Show()
end)
local cccTxtFilterFriendly = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtFilterFriendly:SetPoint("LEFT", cccChkFilterFriendly, "RIGHT", 0, 1)
cccTxtFilterFriendly:SetText("Filter Friendly")

------------------
-- Whole Words
------------------
local cccChkWoleWords = CreateFrame("CheckButton", nil, ccc, "OptionsBaseCheckButtonTemplate")
cccChkWoleWords:SetPoint("TOPLEFT", cccTxtFilterFriendly, "TOPRIGHT", 10, 5)
cccChkWoleWords:SetScript("OnClick", function(frame)
	CCLEANER_CLASSIC_WHOLE_WORDS = frame:GetChecked()
end)
cccChkWoleWords:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:AddLine("Filtering keywords are matched as whole words instead of partial.", 0.5, 0.5, 0)
	GameTooltip:Show()
end)
local cccTxtWholeWords = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtWholeWords:SetPoint("LEFT", cccChkWoleWords, "RIGHT", 0, 1)
cccTxtWholeWords:SetText("Match Whole Words")

------------------
-- Channels
------------------
local cccInputChan = CreateFrame("EditBox", nil, ccc, "InputBoxTemplate")
cccInputChan:SetAutoFocus(false)
cccInputChan:EnableMouse(true)
cccInputChan:SetWidth(190)
cccInputChan:SetHeight(20)
cccInputChan:SetMaxLetters(99999)
cccInputChan:SetScript("OnEscapePressed", function(frame)
	frame:ClearFocus()
end)
cccInputChan:SetScript("OnEnterPressed", function(frame) SetChannels(frame:GetText()) frame:ClearFocus() end)
cccInputChan:Show()
------------------
cccInputChan:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:AddLine("Only affect chat on these channel names (separated by semi-colons).\nLeave empty for all named channels.\nExample: LookingForGroup;LFG", 0.5, 0.5, 0)
	GameTooltip:Show()
end)
cccInputChan:SetScript("OnLeave", GameTooltip_Hide)
------------------
local cccChanText = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccChanText:SetPoint("TOPLEFT", cccTxtGeneral, "BOTTOMLEFT", 0, -12)
cccChanText:SetText("Affected Channels:")
cccInputChan:SetPoint("TOPLEFT", cccChanText, "TOPRIGHT", 15, 2)

------------------
-- Filter Say Chat
------------------
local cccChkFilterSay = CreateFrame("CheckButton", nil, ccc, "OptionsBaseCheckButtonTemplate")
cccChkFilterSay:SetPoint("TOPLEFT", cccInputChan, "TOPRIGHT", 5, 3)
cccChkFilterSay:SetScript("OnClick", function(frame)
	CCLEANER_CLASSIC_FILTER_SAY = frame:GetChecked()
end)
local cccTxtFilterSay = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtFilterSay:SetPoint("LEFT", cccChkFilterSay, "RIGHT", 0, 1)
cccTxtFilterSay:SetText("Filter Say Chat")

------------------
-- Filter Yell Chat
------------------
local cccChkFilterYell = CreateFrame("CheckButton", nil, ccc, "OptionsBaseCheckButtonTemplate")
cccChkFilterYell:SetPoint("TOPLEFT", cccTxtFilterSay, "TOPRIGHT", 5, 5)
cccChkFilterYell:SetScript("OnClick", function(frame)
	CCLEANER_CLASSIC_FILTER_YELL = frame:GetChecked()
end)
local cccTxtFilterYell = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtFilterYell:SetPoint("LEFT", cccChkFilterYell, "RIGHT", 0, 1)
cccTxtFilterYell:SetText("Filter Yell Chat")

------------------
-- Required Keywords
------------------
local cccInputReq = CreateFrame("EditBox", nil, ccc, "InputBoxTemplate")
cccInputReq:SetAutoFocus(false)
cccInputReq:EnableMouse(true)
cccInputReq:SetWidth(100)
cccInputReq:SetHeight(20)
cccInputReq:SetMaxLetters(100)
cccInputReq:SetScript("OnEscapePressed", function(frame)
	frame:SetText("")
	frame:ClearFocus()
end)
cccInputReq:SetScript("OnTextChanged", function(frame, changed)
	if changed then
		local msg = (frame:GetText()):lower()
		frame:SetText(msg)
	end
end)
cccInputReq:Show()
------------------
local cccBtnReqAR = CreateFrame("Button", nil, ccc, "UIPanelButtonTemplate")
cccBtnReqAR:SetWidth(90)
cccBtnReqAR:SetHeight(20)
cccBtnReqAR:SetPoint("LEFT", cccInputReq, "RIGHT")
cccBtnReqAR:SetText(ADD.."/"..REMOVE)
------------------
cccInputReq:SetScript("OnEnterPressed", function() cccBtnReqAR:Click() end)
cccInputReq:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:AddLine("Chats must have at least one of these keywords to be shown.\nLeave empty to bypass.", 0.5, 0.5, 0)
	GameTooltip:Show()
end)
cccInputReq:SetScript("OnLeave", GameTooltip_Hide)
------------------
local cccTxtReq = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtReq:SetPoint("TOPLEFT", cccChanText, "BOTTOMLEFT", 0, -15)
cccTxtReq:SetText("Required keywords:")
cccInputReq:SetPoint("TOPLEFT", cccTxtReq, "TOPRIGHT", 10, 3)

------------------
-- Required Table
------------------
local cccEditReq = CreateFrame("EditBox", nil, ccc)
cccEditReq:SetMultiLine(true)
cccEditReq:SetMaxLetters(99999)
cccEditReq:EnableMouse(false)
cccEditReq:SetAutoFocus(false)
cccEditReq:SetFontObject(ChatFontNormal)
cccEditReq:SetWidth(350)
cccEditReq:SetHeight(100)
cccEditReq:Show()
------------------
local cccScrollReq = CreateFrame("ScrollFrame", nil, ccc, "UIPanelScrollFrameTemplate")
cccScrollReq:SetPoint("TOPLEFT", cccTxtReq, "BOTTOMLEFT", 3, -7)
cccScrollReq:SetHeight(cccEditReq:GetHeight())
cccScrollReq:SetScrollChild(cccEditReq)
------------------
local cccBGFReq = CreateFrame("Frame", nil, ccc)
cccBGFReq:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
	edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
	tile = true, tileSize = 16, edgeSize = 16,
	insets = {left = 3, right = 3, top = 5, bottom = 3}}
)
cccBGFReq:SetBackdropColor(0,0,0,1)
cccBGFReq:SetPoint("TOPLEFT", cccTxtReq, "BOTTOMLEFT", -5, -2)
cccBGFReq:SetWidth(cccTxtReq:GetWidth() + cccInputReq:GetWidth() + cccBtnReqAR:GetWidth() + 15)
cccBGFReq:SetHeight(cccScrollReq:GetHeight() + 10)
cccScrollReq:SetWidth(cccBGFReq:GetWidth() - 37)
------------------
local cccBtnReqCA = CreateFrame("Button", nil, ccc, "UIPanelButtonTemplate")
cccBtnReqCA:SetWidth(70)
cccBtnReqCA:SetHeight(20)
cccBtnReqCA:SetPoint("TOPLEFT", cccBGFReq, "BOTTOMLEFT", (cccBGFReq:GetWidth() / 2) - (cccBtnReqCA:GetWidth() / 2), 0)
cccBtnReqCA:SetText("Clear All")

------------------
-- Clean Keywords
------------------
local cccInputClean = CreateFrame("EditBox", nil, ccc, "InputBoxTemplate")
cccInputClean:SetAutoFocus(false)
cccInputClean:EnableMouse(true)
cccInputClean:SetWidth(100)
cccInputClean:SetHeight(20)
cccInputClean:SetMaxLetters(100)
cccInputClean:SetScript("OnEscapePressed", function(frame)
	frame:SetText("")
	frame:ClearFocus()
end)
cccInputClean:SetScript("OnTextChanged", function(frame, changed)
	if changed then
		local msg = (frame:GetText()):lower()
		frame:SetText(msg)
	end
end)
cccInputClean:Show()
------------------
local cccBtnCleanAR = CreateFrame("Button", nil, ccc, "UIPanelButtonTemplate")
cccBtnCleanAR:SetWidth(90)
cccBtnCleanAR:SetHeight(20)
cccBtnCleanAR:SetPoint("LEFT", cccInputClean, "RIGHT")
cccBtnCleanAR:SetText(ADD.."/"..REMOVE)
------------------
cccInputClean:SetScript("OnEnterPressed", function() cccBtnCleanAR:Click() end)
cccInputClean:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:AddLine("Chats found with any of these keywords will be removed (even if a required keyword is found).\n", 0.5, 0.5, 0)
	GameTooltip:Show()
end)
cccInputClean:SetScript("OnLeave", GameTooltip_Hide)
------------------
local cccTxtClean = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtClean:SetPoint("TOPLEFT", cccBtnReqAR, "TOPRIGHT", 10, -3)
cccTxtClean:SetText("Clean keywords:")
cccInputClean:SetPoint("TOPLEFT", cccTxtClean, "TOPRIGHT", 10, 3)

------------------
-- Clean Table
------------------
local cccEditClean = CreateFrame("EditBox", nil, ccc)
cccEditClean:SetMultiLine(true)
cccEditClean:SetMaxLetters(99999)
cccEditClean:EnableMouse(false)
cccEditClean:SetAutoFocus(false)
cccEditClean:SetFontObject(ChatFontNormal)
cccEditClean:SetWidth(350)
cccEditClean:SetHeight(100)
cccEditClean:Show()
------------------
local cccScrollClean = CreateFrame("ScrollFrame", nil, ccc, "UIPanelScrollFrameTemplate")
cccScrollClean:SetPoint("TOPLEFT", cccTxtClean, "BOTTOMLEFT", 3, -7)
cccScrollClean:SetWidth(ccc:GetWidth() - 45)
cccScrollClean:SetHeight(cccEditClean:GetHeight())
cccScrollClean:SetScrollChild(cccEditClean)
------------------
local cccBGFClean = CreateFrame("Frame", nil, ccc)
cccBGFClean:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
	edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
	tile = true, tileSize = 16, edgeSize = 16,
	insets = {left = 3, right = 3, top = 5, bottom = 3}}
)
cccBGFClean:SetBackdropColor(0,0,0,1)
cccBGFClean:SetPoint("TOPLEFT", cccTxtClean, "BOTTOMLEFT", -5, -2)
cccBGFClean:SetWidth(cccTxtClean:GetWidth() + cccInputClean:GetWidth() + cccBtnCleanAR:GetWidth() + 15)
cccBGFClean:SetHeight(cccScrollClean:GetHeight() + 10)
cccScrollClean:SetWidth(cccBGFClean:GetWidth() - 37)
------------------
local cccBtnCleanCA = CreateFrame("Button", nil, ccc, "UIPanelButtonTemplate")
cccBtnCleanCA:SetWidth(70)
cccBtnCleanCA:SetHeight(20)
cccBtnCleanCA:SetPoint("TOPLEFT", cccBGFClean, "BOTTOMLEFT", (cccBGFClean:GetWidth() / 2) - (cccBtnCleanCA:GetWidth() / 2), 0)
cccBtnCleanCA:SetText("Clear All")

------------------
-- Export to Account Vars
------------------
local cccBtnExport = CreateFrame("Button", nil, ccc, "UIPanelButtonTemplate")
cccBtnExport:SetWidth(cccBGFReq:GetWidth())
cccBtnExport:SetHeight(25)
cccBtnExport:SetPoint("TOP",  ccc, "BOTTOM", 0, 30)
cccBtnExport:SetPoint("LEFT", cccBGFReq, "LEFT")
cccBtnExport:SetText("Export All Settings to Account Vars")
cccBtnExport:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:AddLine("Click to export these settings to the account-wide variables.\nYou can then log on to another character and import these settings to that character.", 0.5, 0.5, 0)
	GameTooltip:Show()
end)

------------------
-- Import From Account Vars
------------------
local cccBtnImport = CreateFrame("Button", nil, ccc, "UIPanelButtonTemplate")
cccBtnImport:SetWidth(cccBGFClean:GetWidth())
cccBtnImport:SetHeight(25)
cccBtnImport:SetPoint("TOP",  cccBtnExport, "TOP")
cccBtnImport:SetPoint("LEFT", cccBGFClean, "LEFT")
cccBtnImport:SetText("Import All Settings from Account Vars")
cccBtnImport:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:AddLine("Click to import previously exported settings from the account-wide variables.\nSee export tooltip for more info.", 0.5, 0.5, 0)
	GameTooltip:Show()
end)

------------------
-- Import/Export status
------------------
local cccTxtIEStatus = ccc:CreateFontString(nil, nil, "GameFontHighlight")
cccTxtIEStatus:SetPoint("TOP",  cccBtnExport,  "TOP", 0, 17)
cccTxtIEStatus:SetPoint("LEFT", cccTxtGeneral, "LEFT")
cccTxtIEStatus:SetWidth(ccc:GetWidth() - 30)
cccTxtIEStatus:SetJustifyH("CENTER");
cccTxtIEStatus:SetText("")

------------------
-- Add/Remove Button OnClicks
------------------
cccBtnReqAR:SetScript("OnClick", function() 
	AddRemoveKeywords(cccInputReq, cccEditReq, CCLEANER_CLASSIC_REQUIRED) 
end)
cccBtnCleanAR:SetScript("OnClick", function()
	AddRemoveKeywords(cccInputClean, cccEditClean, CCLEANER_CLASSIC_CLEAN)
end)

------------------
-- Clear All OnClicks
------------------
cccBtnReqCA:SetScript("OnClick", function()
	StaticPopupDialogs["CCC_REQ_CA"] = {
	  text = "WARNING: Clearing required keywords cannot be undone.\n\nAre you sure?",
	  button1 = "Yes",
	  button2 = "No",
	  OnAccept = function()
	  	-- clear the keywords...
		for k in pairs(CCLEANER_CLASSIC_REQUIRED) do CCLEANER_CLASSIC_REQUIRED[k] = nil; end
		cccEditReq:SetText("")
	  end,
	  timeout = 0,
	  whileDead = true,
	  hideOnEscape = true,
	  preferredIndex = 3,
	}

	StaticPopup_Show("CCC_REQ_CA")
end)
cccBtnCleanCA:SetScript("OnClick", function()
	StaticPopupDialogs["CCC_CLEAN_CA"] = {
	  text = "WARNING: Clearing clean keywords cannot be undone.\n\nAre you sure?",
	  button1 = "Yes",
	  button2 = "No",
	  OnAccept = function()
	  	-- clear the keywords...
		for k in pairs(CCLEANER_CLASSIC_CLEAN) do CCLEANER_CLASSIC_CLEAN[k] = nil; end
		cccEditClean:SetText("")
	  end,
	  timeout = 0,
	  whileDead = true,
	  hideOnEscape = true,
	  preferredIndex = 3,
	}

	StaticPopup_Show("CCC_CLEAN_CA")	
end)

------------------
-- Status/Init Funcs
------------------
local function SetIEStatusText(text)
	cccTxtIEStatus:SetText(text)
	C_Timer.After(3, function() cccTxtIEStatus:SetText("") end)
end

local function LoadSettings()
	cccChkEnabled:SetChecked(CCLEANER_CLASSIC_ENABLED)
	cccChkFilterFriendly:SetChecked(CCLEANER_CLASSIC_FILTER_FRIENDLY)
	cccChkWoleWords:SetChecked(CCLEANER_CLASSIC_WHOLE_WORDS)
	cccInputChan:SetText(GetChannels())
	cccChkFilterSay:SetChecked(CCLEANER_CLASSIC_FILTER_SAY)
	cccChkFilterYell:SetChecked(CCLEANER_CLASSIC_FILTER_YELL)
	GetKeywords(cccEditReq, 	CCLEANER_CLASSIC_REQUIRED)
	GetKeywords(cccEditClean, 	CCLEANER_CLASSIC_CLEAN)
end

------------------
-- Export OnClick
------------------
cccBtnExport:SetScript("OnClick", function()
	StaticPopupDialogs["CCC_CONFIRM_EXPORT"] = {
	  text = "WARNING: An EXPORT cannot be undone.\n\nAre you sure?",
	  button1 = "Yes",
	  button2 = "No",
	  OnAccept = function()
		-- copy tables...
		TableCopy(CCLEANER_CLASSIC_CHANNELS, 	CCLEANER_CLASSIC_ACCOUNT_CHANNELS);
		TableCopy(CCLEANER_CLASSIC_REQUIRED, 	CCLEANER_CLASSIC_ACCOUNT_REQUIRED);
		TableCopy(CCLEANER_CLASSIC_CLEAN, 		CCLEANER_CLASSIC_ACCOUNT_CLEAN);
		-- other settings...
		CCLEANER_CLASSIC_ACCOUNT_ENABLED =  		CCLEANER_CLASSIC_ENABLED
		CCLEANER_CLASSIC_ACCOUNT_FILTER_FRIENDLY =  CCLEANER_CLASSIC_FILTER_FRIENDLY
		CCLEANER_CLASSIC_ACCOUNT_FILTER_SAY = 		CCLEANER_CLASSIC_FILTER_SAY
		CCLEANER_CLASSIC_ACCOUNT_FILTER_YELL = 		CCLEANER_CLASSIC_FILTER_YELL
		CCLEANER_CLASSIC_ACCOUNT_WHOLE_WORDS = 		CCLEANER_CLASSIC_WHOLE_WORDS
		SetIEStatusText("Settings exported to account vars successfully!")
	  end,
	  timeout = 0,
	  whileDead = true,
	  hideOnEscape = true,
	  preferredIndex = 3,
	}

	StaticPopup_Show("CCC_CONFIRM_EXPORT")
end)

------------------
-- Import OnClick
------------------
cccBtnImport:SetScript("OnClick", function()
	StaticPopupDialogs["CCC_CONFIRM_IMPORT"] = {
		text = "WARNING: An IMPORT cannot be undone.\n\nAre you sure?",
		button1 = "Yes",
		button2 = "No",
		OnAccept = function()
			-- copy tables...
			TableCopy(CCLEANER_CLASSIC_ACCOUNT_CHANNELS, 	CCLEANER_CLASSIC_CHANNELS);
			TableCopy(CCLEANER_CLASSIC_ACCOUNT_REQUIRED, 	CCLEANER_CLASSIC_REQUIRED);
			TableCopy(CCLEANER_CLASSIC_ACCOUNT_CLEAN, 		CCLEANER_CLASSIC_CLEAN);
			-- other settings...
			CCLEANER_CLASSIC_ENABLED =  		CCLEANER_CLASSIC_ACCOUNT_ENABLED
			CCLEANER_CLASSIC_FILTER_FRIENDLY =  CCLEANER_CLASSIC_ACCOUNT_FILTER_FRIENDLY
			CCLEANER_CLASSIC_FILTER_SAY = 		CCLEANER_CLASSIC_ACCOUNT_FILTER_SAY
			CCLEANER_CLASSIC_FILTER_YELL = 		CCLEANER_CLASSIC_ACCOUNT_FILTER_YELL
			CCLEANER_CLASSIC_WHOLE_WORDS = 		CCLEANER_CLASSIC_ACCOUNT_WHOLE_WORDS
			SetIEStatusText("Settings imported from account vars successfully!")
			LoadSettings()
		end,
		timeout = 0,
		whileDead = true,
		hideOnEscape = true,
		preferredIndex = 3,
	}

	StaticPopup_Show("CCC_CONFIRM_IMPORT")	
end)

------------------
-- Main Frame: Load Settings
------------------
ccc:SetScript("OnShow",  function() LoadSettings() end)
