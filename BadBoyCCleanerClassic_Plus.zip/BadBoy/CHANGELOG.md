# BadBoy

## [v1-classic](https://github.com/funkydude/BadBoy/tree/v1-classic) (2019-08-09)
[Full Changelog](https://github.com/funkydude/BadBoy/compare/v8.2.3...v1-classic)

- classic update  
