------------------
-- Friendly Check
------------------
local function IsFriendly(name, flag, _, guid)
	if not guid then return true end -- LocalDefense automated prints
	if not guid:find("^Player") then
		local msg = "CCC: Unexpected GUID requested by an addon: ".. guid
		print(msg)
		geterrorhandler()(msg)
		return true
	end
	local _, characterName = BNGetGameAccountInfoByGUID(guid)
	if characterName or IsGuildMember(guid) or C_FriendList.IsFriend(guid) or UnitInRaid(name) or UnitInParty(name) or flag == "GM" or flag == "DEV" then
		return true
	end
end

------------------
-- String Search Function
------------------
local function StringSearch(msg, kw)
	-- print ("CCC: msg=" .. msg .. " >>>> kw=" .. kw)
	-- special: check for ecncapsulating symbols that exist around the word (like <GUILD NAMES>)...
	local encapsulated_word = 
		(kw:sub(1, 1) == "<" or kw:sub(1, 1) == "{" or kw:sub(1, 1) == "[" or kw:sub(1, 1) == "(") and
		(kw:sub(-1)   == ">" or kw:sub(-1)   == "}" or kw:sub(-1)   == "]" or kw:sub(-1)   == ")")
	return 
		( CCLEANER_CLASSIC_WHOLE_WORDS == true  and string.find(msg, "%f[%w_]" .. kw .. "%f[^%w_]")) or
		((CCLEANER_CLASSIC_WHOLE_WORDS == false or encapsulated_word) and msg:find(kw, nil, true))
end

------------------
-- Startup + Set Filter
------------------
local ccc = CreateFrame("Frame")
ccc:RegisterEvent("ADDON_LOADED")
ccc:RegisterEvent("PLAYER_ENTERING_WORLD")
local function EventHandler(self, event, sender, arg1, ...)
	-- addon loaded - start filtering now...
	if (event == "ADDON_LOADED") and (sender == "CCleanerClassic") then
		ccc:UnregisterEvent("ADDON_LOADED")
		
		-- validate variables...
		if CCLEANER_CLASSIC_WHOLE_WORDS == nil then 		CCLEANER_CLASSIC_WHOLE_WORDS = true end
		if CCLEANER_CLASSIC_FILTER_FRIENDLY == nil then 	CCLEANER_CLASSIC_FILTER_FRIENDLY = false end
		if CCLEANER_CLASSIC_FILTER_SAY == nil then 			CCLEANER_CLASSIC_FILTER_SAY = false end
		if CCLEANER_CLASSIC_FILTER_YELL == nil then 		CCLEANER_CLASSIC_FILTER_YELL = false end
		if type(CCLEANER_CLASSIC_REQUIRED) ~= "table" then 	CCLEANER_CLASSIC_REQUIRED = {} end
		if type(CCLEANER_CLASSIC_CHANNELS) ~= "table" then 	CCLEANER_CLASSIC_CHANNELS = {} end
		if type(CCLEANER_CLASSIC_CLEAN) ~= "table" then		CCLEANER_CLASSIC_CLEAN = {"anal", "rape"} end
		-- validate account variables...
		if CCLEANER_CLASSIC_ACCOUNT_WHOLE_WORDS == nil then 		CCLEANER_CLASSIC_ACCOUNT_WHOLE_WORDS = true end
		if CCLEANER_CLASSIC_ACCOUNT_FILTER_FRIENDLY == nil then 	CCLEANER_CLASSIC_ACCOUNT_FILTER_FRIENDLY = false end
		if CCLEANER_CLASSIC_ACCOUNT_FILTER_SAY == nil then 			CCLEANER_CLASSIC_ACCOUNT_FILTER_SAY = false end
		if CCLEANER_CLASSIC_ACCOUNT_FILTER_YELL == nil then 		CCLEANER_CLASSIC_ACCOUNT_FILTER_YELL = false end
		if type(CCLEANER_CLASSIC_ACCOUNT_REQUIRED) ~= "table" then 	CCLEANER_CLASSIC_ACCOUNT_REQUIRED = {} end
		if type(CCLEANER_CLASSIC_ACCOUNT_CHANNELS) ~= "table" then 	CCLEANER_CLASSIC_ACCOUNT_CHANNELS = {} end
		if type(CCLEANER_CLASSIC_ACCOUNT_CLEAN) ~= "table" then 	CCLEANER_CLASSIC_ACCOUNT_CLEAN = {"anal", "rape"} end

		--main filtering function
		local prevLineId, result = 0, nil
		local filter = function(_,event,msg,player,_,_,_,flag,chid,chnum,chname,_,lineId,guid)
			if lineId == prevLineId then
				return result
			else
				-- print ("CCC: chname=" .. (chname or "nil") .. " >>>> chatMsg chnum=" .. (chnum or "nil"))
				-- print ("CCC: #CCLEANER_CLASSIC_CHANNELS=" .. #CCLEANER_CLASSIC_CHANNELS)
				-- print ("CCC: msg1=" .. msg)
				-- print ("CCC: event=" .. event .. " >>>> chid=" .. chid .. " >>>> chname=" .. chname)

				prevLineId, result = lineId, nil
				local trimmedPlayer = Ambiguate(player, "none")
				local lowMsg = msg:lower()

				-- always show messages from actual player
				if trimmedPlayer == UnitName("player") then return end
				-- validate channel and event...
				if event == "CHAT_MSG_CHANNEL" and type(chid) ~= "number" then return end
				if event == "CHAT_MSG_SAY"     and CCLEANER_CLASSIC_FILTER_SAY  == false then return end
				if event == "CHAT_MSG_YELL"    and CCLEANER_CLASSIC_FILTER_YELL == false then return end
				-- check if we're filtering friendlies
				if IsFriendly(trimmedPlayer, flag, lineId, guid) and CCLEANER_CLASSIC_FILTER_FRIENDLY == false then return end

				-- check for a say or yell...
				local channel_match = false
				if ((event == "CHAT_MSG_SAY"  	and CCLEANER_CLASSIC_FILTER_SAY  == true) or
					(event == "CHAT_MSG_YELL"   and CCLEANER_CLASSIC_FILTER_YELL == true) or 
					#CCLEANER_CLASSIC_CHANNELS == 0) then
					channel_match = true
				-- else proceed as a standard named channel...
				else
					for i=1, #CCLEANER_CLASSIC_CHANNELS do
						-- print ("CCC: CCLEANER_CLASSIC_CHANNELS[i]=" .. CCLEANER_CLASSIC_CHANNELS[i] .. " >>>> chname=" .. (chname or "nil"))
						if  chname and chname ~= '' and 
							string.lower(CCLEANER_CLASSIC_CHANNELS[i]) == string.lower(chname) then
							channel_match = true
							break
						end
					end
				end

				if channel_match == true then
					-- scan for required matches (filter if not found)...
					local req_match = false
					for i=1, #CCLEANER_CLASSIC_REQUIRED do 
						-- print ("CCC: lowMsg_req=" .. lowMsg .. " >>>> CCLEANER_CLASSIC_REQUIRED[i]=" .. CCLEANER_CLASSIC_REQUIRED[i])
						if StringSearch(lowMsg, CCLEANER_CLASSIC_REQUIRED[i]) then
							req_match = true
							break
						end
					end

					-- scan for clean matches (filter if found)...
					if  req_match == true or #CCLEANER_CLASSIC_REQUIRED == 0 then
						for i=1, #CCLEANER_CLASSIC_CLEAN do 
							-- print ("CCC: lowMsg2_clean=" .. lowMsg .. " >>>> CCLEANER_CLASSIC_CLEAN[i]=" .. CCLEANER_CLASSIC_CLEAN[i])
							if StringSearch(lowMsg, CCLEANER_CLASSIC_CLEAN[i]) then
								result = true
								break
							end
						end
					else
						-- print ("CCC: lowMsg reqs not met!")
						result = true
					end

					-- logging...
					if result == true then
						-- print ("CCC: FILTERED: " .. msg)
					end

					return result
				end
			end
		end

		-- sub to chat events...
		ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL", filter)
		ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", filter)
		ChatFrame_AddMessageEventFilter("CHAT_MSG_YELL", filter)
	end

	-- show startup message when entering the world (need a delay)...
	if (event == "PLAYER_ENTERING_WORLD") then
		ccc:UnregisterEvent("PLAYER_ENTERING_WORLD")

		-- delay for the startup message...
		local message_delay = 0
		self:SetScript("OnUpdate", function(self, elapsed)
			message_delay = message_delay + elapsed
			if message_delay < 5 then return end
			self:SetScript("OnUpdate", nil)
			self:Hide()
		end)
		print("|cff9999ffCCleanerClassic " .. 
			string.format("v%s", GetAddOnMetadata("CCleanerClassic", "Version")) .. 
			": |cffffffffuse /ccc to open the options panel.")		
	end
end
ccc:SetScript("OnEvent", EventHandler)
