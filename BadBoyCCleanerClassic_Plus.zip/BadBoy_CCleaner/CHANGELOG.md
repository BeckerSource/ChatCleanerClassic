# BadBoy_CCleaner

## [v9.0.0](https://github.com/funkydude/BadBoy_CCleaner/tree/v9.0.0) (2020-10-14)
[Full Changelog](https://github.com/funkydude/BadBoy_CCleaner/compare/v8.2.0...v9.0.0) [Previous Releases](https://github.com/funkydude/BadBoy_CCleaner/releases)

- Fix backdrop for shadowlands  
- bump toc  
- add github directory  
