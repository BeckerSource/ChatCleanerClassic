------------------
-- Friendly Check
------------------
local function IsFriendly(name, flag, _, guid)
	if not guid then return true end -- LocalDefense automated prints
	if not guid:find("^Player") then
		local msg = "CCleanerClassic: Unexpected GUID requested by an addon: ".. guid
		print(msg)
		geterrorhandler()(msg)
		return true
	end
	local _, characterName = BNGetGameAccountInfoByGUID(guid)
	if characterName or IsGuildMember(guid) or C_FriendList.IsFriend(guid) or UnitInRaid(name) or UnitInParty(name) or flag == "GM" or flag == "DEV" then
		return true
	end
end

------------------
-- String Search Function
------------------
local function StringSearch(msg, str)
	return 
		(CCLEANER_CLASSIC_WHOLE_WORDS == true  and string.find(msg, "%f[%w_]" .. str .. "%f[^%w_]")) or
		(CCLEANER_CLASSIC_WHOLE_WORDS == false and msg:find(str, nil, true))
end

------------------
-- Startup + Set Filter
------------------
local ccc = CreateFrame("Frame")
ccc:RegisterEvent("ADDON_LOADED")
ccc:RegisterEvent("PLAYER_ENTERING_WORLD")
local function EventHandler(self, event, sender, arg1, ...)
	-- addon loaded - start filtering now...
	if (event == "ADDON_LOADED") and (sender == "CCleanerClassic") then
		ccc:UnregisterEvent("ADDON_LOADED")

		-- validate main variables...
		if CCLEANER_CLASSIC_FILTER_FRIENDLY == nil then CCLEANER_CLASSIC_FILTER_FRIENDLY = false end
		if CCLEANER_CLASSIC_WHOLE_WORDS == nil then CCLEANER_CLASSIC_WHOLE_WORDS = true end
		if type(CCLEANER_CLASSIC_REQUIRED) ~= "table" then CCLEANER_CLASSIC_REQUIRED = {} end
		if type(CCLEANER_CLASSIC_CHANNELS) ~= "table" then CCLEANER_CLASSIC_CHANNELS = {} end
		if type(CCLEANER_CLASSIC_CLEAN) ~= "table" then
			CCLEANER_CLASSIC_CLEAN = {
				"anal",
				"rape",
			}
		end

		--main filtering function
		local prevLineId, result = 0, nil
		local filter = function(_,event,msg,player,_,_,_,flag,chid,chnum,chname,_,lineId,guid)
			if lineId == prevLineId then
				return result
			else
				-- print ("chname=" .. (chname or "nil") .. " >>>> chatMsg chnum=" .. (chnum or "nil"))
				-- print ("#CCLEANER_CLASSIC_CHANNELS=" .. #CCLEANER_CLASSIC_CHANNELS)
				-- print ("msg1=" .. msg)
				-- print ("event=" .. event .. " >>>> chid=" .. chid .. " >>>> chname=" .. chname)

				prevLineId, result = lineId, nil
				local trimmedPlayer = Ambiguate(player, "none")

				-- only scan channels with a valid channel number
				if event == "CHAT_MSG_CHANNEL" and type(chid) ~= "number" then return end
				-- always show messages from actual player
				if trimmedPlayer == UnitName("player") then return end
				-- check if we're filtering friendlies
				if IsFriendly(trimmedPlayer, flag, lineId, guid) and CCLEANER_CLASSIC_FILTER_FRIENDLY == false then return end

				-- check for required channels (if any)...
				local lowMsg = msg:lower() --lower all text
				local channel_match = false
				for i=1, #CCLEANER_CLASSIC_CHANNELS do
					-- print ("CCLEANER_CLASSIC_CHANNELS[i]=" .. CCLEANER_CLASSIC_CHANNELS[i] .. " >>>> chname=" .. (chname or "nil"))
					if  chname and chname ~= '' and 
						string.lower(CCLEANER_CLASSIC_CHANNELS[i]) == string.lower(chname) then
						channel_match = true
						break
					end
				end

				if channel_match == true or #CCLEANER_CLASSIC_CHANNELS == 0 then
					-- scan for required matches (filter if not found)...
					local req_match = false
					for i=1, #CCLEANER_CLASSIC_REQUIRED do 
						-- print ("lowMsg_req=" .. lowMsg .. " >>>> CCLEANER_CLASSIC_REQUIRED[i]=" .. CCLEANER_CLASSIC_REQUIRED[i])
						if StringSearch(lowMsg, CCLEANER_CLASSIC_REQUIRED[i]) then
							req_match = true
							break
						end
					end

					-- scan for clean matches (filter if found)...
					if  req_match == true or #CCLEANER_CLASSIC_REQUIRED == 0 then
						for i=1, #CCLEANER_CLASSIC_CLEAN do 
							-- print ("lowMsg2_clean=" .. lowMsg .. " >>>> CCLEANER_CLASSIC_CLEAN[i]=" .. CCLEANER_CLASSIC_CLEAN[i])
							if StringSearch(lowMsg, CCLEANER_CLASSIC_CLEAN[i]) then
								result = true
								break
							end
						end
					else
						-- print ("lowMsg reqs not met!")
						result = true
					end

					-- filter due to lack of required keywords or found clean keywords...
					if result == true then
						-- print ("FILTERED: " .. msg)
						-- log filtered words here
						return true 
					end
				end
			end
		end
		ChatFrame_AddMessageEventFilter("CHAT_MSG_CHANNEL", filter)
		ChatFrame_AddMessageEventFilter("CHAT_MSG_YELL", filter)
		ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", filter)
		--ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY", filter)
		--ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", filter)
	end

	-- show startup message when entering the world (need a delay)...
	if (event == "PLAYER_ENTERING_WORLD") then
		ccc:UnregisterEvent("PLAYER_ENTERING_WORLD")

		-- delay for the startup message...
		local message_delay = 0
		self:SetScript("OnUpdate", function(self, elapsed)
			message_delay = message_delay + elapsed
			if message_delay < 5 then return end
			self:SetScript("OnUpdate", nil)
			self:Hide()
		end)
		print("|cff9999ffCCleanerClassic: |cffffffffuse /ccc to open the options panel.")		
	end
end
ccc:SetScript("OnEvent", EventHandler)
